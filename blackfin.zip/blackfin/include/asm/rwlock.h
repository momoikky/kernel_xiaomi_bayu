/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_BLACKFIN_RWLOCK_H
#define _ASM_BLACKFIN_RWLOCK_H

#define RW_LOCK_BIAS	0x01000000

#endif
