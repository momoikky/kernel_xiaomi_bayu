/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _UAPI_BLACKFIN_SIGNAL_H
#define _UAPI_BLACKFIN_SIGNAL_H

#define SA_RESTORER 0x04000000
#include <asm-generic/signal.h>

#endif /* _UAPI_BLACKFIN_SIGNAL_H */
