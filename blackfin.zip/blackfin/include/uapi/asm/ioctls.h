/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _UAPI__ARCH_BFIN_IOCTLS_H__
#define _UAPI__ARCH_BFIN_IOCTLS_H__

#define FIOQSIZE	0x545E
#include <asm-generic/ioctls.h>

#endif /* _UAPI__ARCH_BFIN_IOCTLS_H__ */
