/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _UAPI__BFIN_ASM_BYTEORDER_H
#define _UAPI__BFIN_ASM_BYTEORDER_H

#include <linux/byteorder/little_endian.h>

#endif /* _UAPI__BFIN_ASM_BYTEORDER_H */
