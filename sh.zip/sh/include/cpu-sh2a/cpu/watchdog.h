#include <cpu-sh2/cpu/watchdog.h>
