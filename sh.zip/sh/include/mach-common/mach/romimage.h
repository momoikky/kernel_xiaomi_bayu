/* SPDX-License-Identifier: GPL-2.0 */
#ifdef __ASSEMBLY__

/* do nothing here by default */

#else /* __ASSEMBLY__ */

static inline void mmcif_update_progress(int nr)
{
}

#endif /* __ASSEMBLY__ */
