#ifndef __ASM_CPU_SH2_TIMER_H
#define __ASM_CPU_SH2_TIMER_H

/* Nothing needed yet */

#endif /* __ASM_CPU_SH2_TIMER_H */
