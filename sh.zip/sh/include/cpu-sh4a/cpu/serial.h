/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __CPU_SH4A_SERIAL_H
#define __CPU_SH4A_SERIAL_H

/* arch/sh/kernel/cpu/sh4a/serial-sh7722.c */
extern struct plat_sci_port_ops sh7722_sci_port_ops;

#endif /* __CPU_SH4A_SERIAL_H */
