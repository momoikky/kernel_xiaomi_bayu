#include <linux/screen_info.h>

struct screen_info screen_info;
