/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ALPHA_TYPES_H
#define _ALPHA_TYPES_H

#include <uapi/asm/types.h>

#endif /* _ALPHA_TYPES_H */
