#include "../vdso-fakesections.c"
