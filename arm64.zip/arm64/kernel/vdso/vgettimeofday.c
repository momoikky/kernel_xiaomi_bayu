#include "compiler.h"
#include "datapage.h"
#include "../../../../lib/vdso/vgettimeofday.c"
