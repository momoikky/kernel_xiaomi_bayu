/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASMPARISC_SHMPARAM_H
#define _ASMPARISC_SHMPARAM_H

#define SHMLBA	   PAGE_SIZE	/* attach addr a multiple of this */
#define SHM_COLOUR 0x00400000	/* shared mappings colouring */

#endif /* _ASMPARISC_SHMPARAM_H */
