/*
 * include/asm-parisc/serial.h
 */

/*
 * This is used for 16550-compatible UARTs
 */
#define BASE_BAUD ( 1843200 / 16 )
