/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _PARISC_SETUP_H
#define _PARISC_SETUP_H

#define COMMAND_LINE_SIZE	1024

#endif /* _PARISC_SETUP_H */
