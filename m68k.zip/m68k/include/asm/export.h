#define KSYM_ALIGN 2
#define KCRC_ALIGN 2
#include <asm-generic/export.h>
