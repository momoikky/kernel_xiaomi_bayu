/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _M68K_HP300HW_H
#define _M68K_HP300HW_H

#include <asm/bootinfo-hp300.h>


extern unsigned long hp300_model;

#endif /* _M68K_HP300HW_H */
