/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_SCORE_EXEC_H
#define _ASM_SCORE_EXEC_H

extern unsigned long arch_align_stack(unsigned long sp);

#endif /* _ASM_SCORE_EXEC_H */
