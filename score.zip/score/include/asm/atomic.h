/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_SCORE_ATOMIC_H
#define _ASM_SCORE_ATOMIC_H

#include <asm/cmpxchg.h>
#include <asm-generic/atomic.h>

#endif /* _ASM_SCORE_ATOMIC_H */
