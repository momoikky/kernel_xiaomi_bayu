/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_SCORE_BUGS_H
#define _ASM_SCORE_BUGS_H

#include <asm-generic/bugs.h>

#endif /* _ASM_SCORE_BUGS_H */
