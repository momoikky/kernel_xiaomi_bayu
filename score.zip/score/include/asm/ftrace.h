#ifndef _ASM_SCORE_FTRACE_H
#define _ASM_SCORE_FTRACE_H

#endif /* _ASM_SCORE_FTRACE_H */
