/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _ASM_SCORE_BITSPERLONG_H
#define _ASM_SCORE_BITSPERLONG_H

#include <asm-generic/bitsperlong.h>

#endif /* _ASM_SCORE_BITSPERLONG_H */
