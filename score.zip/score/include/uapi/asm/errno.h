/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _ASM_SCORE_ERRNO_H
#define _ASM_SCORE_ERRNO_H

#include <asm-generic/errno.h>

#endif /* _ASM_SCORE_ERRNO_H */
