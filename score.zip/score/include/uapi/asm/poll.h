/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _ASM_SCORE_POLL_H
#define _ASM_SCORE_POLL_H

#include <asm-generic/poll.h>

#endif /* _ASM_SCORE_POLL_H */
