/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _ASM_SCORE_STAT_H
#define _ASM_SCORE_STAT_H

#include <asm-generic/stat.h>

#endif /* _ASM_SCORE_STAT_H */
