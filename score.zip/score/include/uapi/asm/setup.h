/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _UAPI_ASM_SCORE_SETUP_H
#define _UAPI_ASM_SCORE_SETUP_H

#define COMMAND_LINE_SIZE	256
#define MEMORY_START		0
#define MEMORY_SIZE		0x2000000


#endif /* _UAPI_ASM_SCORE_SETUP_H */
