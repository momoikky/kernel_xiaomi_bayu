/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _CRIS_SETUP_H
#define _CRIS_SETUP_H

#define COMMAND_LINE_SIZE	256

#endif
