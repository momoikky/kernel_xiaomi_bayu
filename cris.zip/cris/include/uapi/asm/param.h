/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _ASMCRIS_PARAM_H
#define _ASMCRIS_PARAM_H

/* Currently we assume that HZ=100 is good for CRIS. */

#define EXEC_PAGESIZE	8192

#include <asm-generic/param.h>

#endif /* _ASMCRIS_PARAM_H */
