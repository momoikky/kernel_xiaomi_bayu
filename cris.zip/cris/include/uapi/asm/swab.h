/*
 * CRIS byte swapping.
 */
