/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_SERIAL_H
#define _ASM_SERIAL_H

/*
 * This assumes you have a 1.8432 MHz clock for your UART.
 */
#define BASE_BAUD (1843200 / 16)

#endif /* _ASM_SERIAL_H */
