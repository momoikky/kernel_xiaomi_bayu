#ifndef _ASM_HW_IRQ_H
#define _ASM_HW_IRQ_H

#endif

