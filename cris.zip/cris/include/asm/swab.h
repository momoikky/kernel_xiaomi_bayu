/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _CRIS_SWAB_H
#define _CRIS_SWAB_H

#include <arch/swab.h>
#include <uapi/asm/swab.h>

#endif /* _CRIS_SWAB_H */
