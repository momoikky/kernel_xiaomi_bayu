/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_CRIS_SHMPARAM_H
#define _ASM_CRIS_SHMPARAM_H

/* same as asm-i386/ version.. */

#define	SHMLBA PAGE_SIZE		 /* attach addr a multiple of this */

#endif /* _ASM_CRIS_SHMPARAM_H */
