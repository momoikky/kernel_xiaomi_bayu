/*
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file "COPYING" in the main directory of this archive
 * for more details.
 *
 * Copyright (c) 2008 Silicon Graphics, Inc.  All Rights Reserved.
 */

#define MACHVEC_PLATFORM_NAME	uv
#define MACHVEC_PLATFORM_HEADER	<asm/machvec_uv.h>
#include <asm/machvec_init.h>
