#define MACHVEC_PLATFORM_NAME		hpsim
#define MACHVEC_PLATFORM_HEADER		<asm/machvec_hpsim.h>
#include <asm/machvec_init.h>
