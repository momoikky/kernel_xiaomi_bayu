#define MACHVEC_PLATFORM_NAME		dig_vtd
#define MACHVEC_PLATFORM_HEADER		<asm/machvec_dig_vtd.h>
#include <asm/machvec_init.h>
