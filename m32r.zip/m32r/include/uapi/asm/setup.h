/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _UAPI_ASM_M32R_SETUP_H
#define _UAPI_ASM_M32R_SETUP_H

/*
 * This is set up by the setup-routine at boot-time
 */

#define COMMAND_LINE_SIZE       512


#endif /* _UAPI_ASM_M32R_SETUP_H */
