/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __ARCH_M32R_PERCPU__
#define __ARCH_M32R_PERCPU__

#include <asm-generic/percpu.h>

#endif /* __ARCH_M32R_PERCPU__ */
