/* 
 * Copyright (C) 2000 Jeff Dike (jdike@karaya.com)
 * Licensed under the GPL
 */

#ifndef __STDIO_CONSOLE_H
#define __STDIO_CONSOLE_H

extern void save_console_flags(void);
#endif

