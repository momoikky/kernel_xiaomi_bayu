/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __UM_TIMEX_H
#define __UM_TIMEX_H

#define CLOCK_TICK_RATE (HZ)

#include <asm-generic/timex.h>

#endif
