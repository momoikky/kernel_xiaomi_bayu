/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __UM_SMP_H
#define __UM_SMP_H

#define hard_smp_processor_id()		0

#endif
