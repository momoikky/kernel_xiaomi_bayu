/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef ___ASM_SPARC_STATFS_H
#define ___ASM_SPARC_STATFS_H

#include <asm-generic/statfs.h>

#endif
