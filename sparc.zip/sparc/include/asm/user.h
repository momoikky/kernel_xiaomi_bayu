#ifndef _SPARC_USER_H
#define _SPARC_USER_H

/* Nothing to define.  */

#endif /* !(_SPARC_USER_H) */
