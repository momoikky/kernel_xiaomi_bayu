/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __ARCH_SPARC_PERCPU__
#define __ARCH_SPARC_PERCPU__

#include <asm-generic/percpu.h>

#endif /* __ARCH_SPARC_PERCPU__ */
