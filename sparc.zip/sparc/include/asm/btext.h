/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _SPARC_BTEXT_H
#define _SPARC_BTEXT_H

int btext_find_display(void);

#endif /* _SPARC_BTEXT_H */
