/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_SPARC_TOPOLOGY_H
#define _ASM_SPARC_TOPOLOGY_H

#include <asm-generic/topology.h>

#endif /* _ASM_SPARC_TOPOLOGY_H */
