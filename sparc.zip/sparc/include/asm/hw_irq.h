#ifndef __ASM_SPARC_HW_IRQ_H
#define __ASM_SPARC_HW_IRQ_H

/* Dummy include. */

#endif
