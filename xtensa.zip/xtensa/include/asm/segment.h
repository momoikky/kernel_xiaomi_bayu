/*
 * include/asm-xtensa/segment.h
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file "COPYING" in the main directory of this archive
 * for more details.
 *
 * Copyright (C) 2001 - 2005 Tensilica Inc.
 */

#ifndef _XTENSA_SEGMENT_H
#define _XTENSA_SEGMENT_H

#include <linux/uaccess.h>

#endif	/* _XTENSA_SEGEMENT_H */
