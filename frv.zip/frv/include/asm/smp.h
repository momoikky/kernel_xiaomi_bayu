/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __ASM_SMP_H
#define __ASM_SMP_H


#ifdef CONFIG_SMP
#error SMP not supported
#endif

#endif
