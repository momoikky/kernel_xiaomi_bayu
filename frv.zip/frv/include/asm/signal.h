/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_SIGNAL_H
#define _ASM_SIGNAL_H

#include <uapi/asm/signal.h>

#endif /* _ASM_SIGNAL_H */
