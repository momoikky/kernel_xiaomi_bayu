/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef __ASM_IOCTLS_H__
#define __ASM_IOCTLS_H__

#define TIOCTTYGSTRUCT	0x5426  /* For debugging only */
#define FIOQSIZE	0x545E

#include <asm-generic/ioctls.h>

#endif /* __ASM_IOCTLS_H__ */

