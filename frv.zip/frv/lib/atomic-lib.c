// SPDX-License-Identifier: GPL-2.0

#include <linux/export.h>
#include <asm/atomic.h>

#define __ATOMIC_LIB__

#include <asm/atomic_defs.h>
