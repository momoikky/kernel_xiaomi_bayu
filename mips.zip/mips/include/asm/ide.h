/*
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file "COPYING" in the main directory of this archive
 * for more details.
 *
 * This file contains the MIPS architecture specific IDE code.
 */
#ifndef __ASM_IDE_H
#define __ASM_IDE_H

#include <ide.h>

#endif /* __ASM_IDE_H */
