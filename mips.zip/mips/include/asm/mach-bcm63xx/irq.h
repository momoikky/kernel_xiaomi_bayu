/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __ASM_MACH_BCM63XX_IRQ_H
#define __ASM_MACH_BCM63XX_IRQ_H

#define NR_IRQS 128
#define MIPS_CPU_IRQ_BASE 0

#endif
