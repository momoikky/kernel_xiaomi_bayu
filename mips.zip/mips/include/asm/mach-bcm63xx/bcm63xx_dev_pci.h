/* SPDX-License-Identifier: GPL-2.0 */
#ifndef BCM63XX_DEV_PCI_H_
#define BCM63XX_DEV_PCI_H_

extern int bcm63xx_pci_enabled;

#endif /* BCM63XX_DEV_PCI_H_ */
