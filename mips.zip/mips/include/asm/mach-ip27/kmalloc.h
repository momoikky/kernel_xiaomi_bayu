#ifndef __ASM_MACH_IP27_KMALLOC_H
#define __ASM_MACH_IP27_KMALLOC_H

/*
 * All happy, no need to define ARCH_DMA_MINALIGN
 */

#endif /* __ASM_MACH_IP27_KMALLOC_H */
