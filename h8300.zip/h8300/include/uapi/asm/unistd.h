#define __ARCH_NOMMU

#define __ARCH_WANT_RENAMEAT

#include <asm-generic/unistd.h>
