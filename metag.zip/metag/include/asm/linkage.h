/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __ASM_LINKAGE_H
#define __ASM_LINKAGE_H

#define __ALIGN .p2align 2
#define __ALIGN_STR ".p2align 2"

#endif
