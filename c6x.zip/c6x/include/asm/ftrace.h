#ifndef _ASM_C6X_FTRACE_H
#define _ASM_C6X_FTRACE_H

/* empty */

#endif /* _ASM_C6X_FTRACE_H */
