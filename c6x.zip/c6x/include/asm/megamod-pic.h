/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _C6X_MEGAMOD_PIC_H
#define _C6X_MEGAMOD_PIC_H

#ifdef __KERNEL__

extern void __init megamod_pic_init(void);

#endif /* __KERNEL__ */
#endif /* _C6X_MEGAMOD_PIC_H */
